# Loan-Prediction

#I created a model to predict the approval of home loans. In the first notebook I tackled the null data. Then I conducted an exploratory data analysis to gain a better understanding of the data. Finally I used a gradient boosting classifier to make predictions on the test set.

#Data and further information can be obtained here: https://datahack.analyticsvidhya.com/contest/practice-problem-loan-prediction-iii/
